//
//  quick.h
//  salt-pepper-noise
//
//  Created by Gabriel Bellon on 20/05/15.
//  Copyright (c) 2015 Gabriel Bellon. All rights reserved.
//

#define MAX_NAME 256
#define MAX 512

int particione(int a[9], int p, int r);
void quicksort(int a[9], int p, int r);
